#include<stdio.h>
void fcfs(int[],int,int[]);
void sjf(int[][6],int);
void srtf(int[],int[],int[],int);
void prioritySchedule(int[],int[],int[],int);
void roundRobin(int[],int[],int[],int,int);

